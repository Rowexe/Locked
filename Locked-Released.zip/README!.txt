Hi User!

This is a released app (finally!), NOTE: This app may still have bugs

Instructions, 

Please run this program and go through all the steps that the program tell you, this is still in build so it may have some problems, if you notice anything
please email me at : rowexe7@gmail.com

Rules,

Please do not claim this product as your own, as it is not made by you, if you want to share this program with anyone, please give them the download link
Any tampering with this program is NOT tolerated
Please do not save super important data and carelessly upload it anywhere thinking it can't be decoded, even though this program ensures the data won't be hacked, or decoded, there is nothing 
known as "safe", please just use this program if you want to keep your stuff encrypted and also want to save some space.

What is going to be appearing in the future,

Currently working on creating auto serviceable parts in this program so that if something breaks, you don't have to redownload everything
Currently working on creating parts which will auto update in case a update arives, this is done so that you don't need to keep on downloading latest updates!


Credits:

Application icon link credit:

https://www.bing.com/images/search?view=detailV2&ccid=NwU29a7y&id=307573DF94E4C83C3A25A223309A85E2FCABBC9E&thid=OIP.NwU29a7ykH_PVUlLpybudgHaHa&mediaurl=https%3A%2F%2F
www.supercheapauto.com.au%2Fdw%2Fimage%2Fv2%2FBBRV_PRD%2Fon%2Fdemandware.static%2F-%2FSites-srg-internal-master-catalog%2Fdefault%2Fdw4e0a1a48%2Fimages%2F283641%2FSCA_283641_hi-res.j
pg%3Fsw%3D558%26sh%3D558%26sm%3Dfit&cdnurl=https%3A%2F%2Fth.bing.com%2Fth%2Fid%2FR.370536f5aef2907fcf55494ba726ee76%3Frik%3Dnr
yr%252fOKFmjAjog%26pid%3DImgRaw%26r%3D0&exph=558&expw=558&q=lock&simid=608004770482300195&form=IRPRST&ck=E3117953DBCD5A38E69DC4A658744529&selectedindex=20&ajaxhist=0&ajaxserp=0&vt=0&sim=11